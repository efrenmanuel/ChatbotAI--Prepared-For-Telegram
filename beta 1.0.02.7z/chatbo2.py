# -*- coding: utf8-*-


import telepot, time, re, os, json, numpy, decimal,AI
from decimal import Decimal, localcontext
import telepot.api
global last_msg

estatus=1

TOKEN = "254702066:AAHgKYxVx5A0qDy2Mx6Xu7XxrKuhWhNR494"
bot = telepot.Bot(TOKEN)

def talk(text, estatus):
    rawdata=AI.talk(text,estatus)
    probs=list(rawdata.values())
    totalprob=0
    for i in probs:
      totalprob=totalprob+i
    for i in range (0,len(probs)):
      probs[i]=decimal.Decimal(probs[i])/totalprob
      print(probs)
    answsheet=json.load(open("answ.json"))
    print(answsheet[numpy.random.choice(list(rawdata.keys()),p=probs)])
    return(answsheet[numpy.random.choice(list(rawdata.keys()),p=probs)])

def listen(text,chat,estatus, *args):
    AI.learn(text,chat,estatus, *args)

def handle(msg):
    estatus=1
    content_type, chat_type, chat_id = telepot.glance(msg)
    idn=str(msg["from"]["id"])
    idg = str(chat_id)
    banned=0
    banned_words=["yiff","http",".com",".net",".org",".es",".co.uk","nuke","triggered"," puto"," puta"," soputa","penis","dick","cunt","fag","pene","vagina","gilipollas","cum","fucker"]
    if content_type=="text":
       
        for i in banned_words:
            if i in msg["text"]:
                banned=1
                break
    if content_type=="text" and not banned==1:
        reply=0
        try:
            if msg["reply_to_message"]["from"]["username"]=="Chatwolf_bot":
                reply=1
        except:
            reply=0
        text=msg["text"].replace("\n","%$space%$").replace("\"","%$quote%$").replace("\'","%$quot%$").replace("\{","%$dic1%$").replace("\}","%$dic2%$")

        if chat_type=="private" or "chatwolf" in text.lower() or " @Chatwolf_bot" in text or reply:
            bot.sendMessage(chat_id,talk(text.replace("@Chatwolf_bot ","").replace("chatwolf","").replace("Chatwolf",""),estatus).replace("$$$$$$&&","\\U").replace("$$&&$$&&","\\u").replace("%$space%$","\n").replace("%$quote%$","\"").replace("%$quot%$","\'").replace("%$dic1%$","\{").replace("%$dic2%$","\}"))
        else:
            try:
                listen(text,str(chat_id),estatus, msg["reply_to_message"]["text"])
            except:
                listen(text,str(chat_id),estatus)
            
bot.message_loop(handle)
while("true"):
    time.sleep(1)
