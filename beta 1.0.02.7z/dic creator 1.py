import json, os
dic={1:{"nice, what about you?":1}}
with open("answ.json","w") as f:
  json.dump(dic, f, indent=4)
